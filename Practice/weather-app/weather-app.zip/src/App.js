import './App.css';
import Header from "./components/Header";
import CurrentWeatherContainer from "./components/CurrentWeather/CurrentWeatherContainer";

function App() {
  // const [first, setfirst] = useState(second)
  return (
    <div className="App">
      <Header />
      <img src="./images/Bliss.jpg" alt="bliss" className="image"/>
      <CurrentWeatherContainer weather="sunny" temp="80"/>
    </div>
  );
}

export default App;
